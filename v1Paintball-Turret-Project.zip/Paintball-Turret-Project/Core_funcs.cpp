#include "core.hpp"        // for Core definition
#include <iostream>         // for std::cout, std::cerr
#include <stdexcept>        // for std::runtime_error
#include <cstdlib>          // for std::system
#include <fstream>          // for std::ifstream, std::ofstream
#include <cstddef>          // for std::size_t
#include <cstdint>          // for uint8_t
#include <string>           // for std::string

namespace {
// Very small helper to extract an integer after a given JSON key in a tiny file.
// This is not a general JSON parser; it just finds e.g. "width": 123.
bool extractIntFromJson(const std::string& path, const std::string& key, long& out) {
    std::ifstream in(path);
    if (!in) return false;
    std::string s((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
    auto pos = s.find('"' + key + '"');
    if (pos == std::string::npos) return false;
    pos = s.find(':', pos);
    if (pos == std::string::npos) return false;
    // Move past ':' and whitespace
    ++pos;
    while (pos < s.size() && (s[pos] == ' ' || s[pos] == '\t')) ++pos;
    // Read numberi
    bool neg = false;
    if (pos < s.size() && s[pos] == '-') { neg = true; ++pos; }
    long val = 0; bool any = false;
    while (pos < s.size() && std::isdigit(static_cast<unsigned char>(s[pos]))) {
        any = true;
        val = val * 10 + (s[pos] - '0');
        ++pos;
    }
    if (!any) return false;
    out = neg ? -val : val;
    return true;
}
}

void Core::imageProcessor() {
    const int CHANNELS = 3;  // R, G, B

    // Try to generate outputs with Python helper (non-fatal if missing Pillow).
    // Preferred: get_matrix_data.py writes image/out/pythonoutput.bin and meta.json
    // Fallbacks handled below.
    (void)std::system("python3 python/get_matrix_data.py > /dev/null 2>&1");

    // First attempt: read width/height from image/out/meta.json (written by get_matrix_data.py)
    long w = -1, h = -1;
    if (!extractIntFromJson("image/out/meta.json", "width", w) ||
        !extractIntFromJson("image/out/meta.json", "height", h)) {
        // Second attempt: use legacy get_dimensions.py which writes pythonoutput.txt
        if (std::system("python3 python/get_dimensions.py > /dev/null 2>&1") == 0) {
            std::ifstream din("pythonoutput.txt");
            if (din) {
                din >> w >> h;
            }
        }
    }

    if (w <= 0 || h <= 0) {
        // Final fallback: pick a tiny default so the program can run
        w = 8; h = 8;
        std::cerr << "Warning: could not determine image dimensions; using "
                  << w << "x" << h << " fallback.\n";
    }

    origWidth  = static_cast<std::size_t>(w);
    origHeight = static_cast<std::size_t>(h);
    m = origWidth;
    n = origHeight;

    matrix.clear();
    matrix.resize(static_cast<std::size_t>(CHANNELS) * origHeight * origWidth);

    // Try to read raw RGB bytes. Preferred path written by get_matrix_data.py
    auto read_bin = [&](const std::string& path) -> bool {
        std::ifstream in(path, std::ios::binary);
        if (!in) return false;
        in.read(reinterpret_cast<char*>(matrix.data()),
                static_cast<std::streamsize>(matrix.size() * sizeof(uint8_t)));
        return static_cast<std::size_t>(in.gcount()) == matrix.size() * sizeof(uint8_t);
    };

    bool ok = read_bin("image/out/pythonoutput.bin");
    if (!ok) {
        ok = read_bin("pythonoutput.bin");
    }
    if (!ok) {
        // If still not available, fill with a simple gradient so downstream logic can proceed.
        for (std::size_t y = 0; y < origHeight; ++y) {
            for (std::size_t x = 0; x < origWidth; ++x) {
                std::size_t idx = (y * origWidth + x) * CHANNELS;
                matrix[idx + 0] = static_cast<uint8_t>((x * 255) / (origWidth  ? origWidth - 1  : 1));
                matrix[idx + 1] = static_cast<uint8_t>((y * 255) / (origHeight ? origHeight - 1 : 1));
                matrix[idx + 2] = 0;
            }
        }
        std::cerr << "Warning: no binary pixel data found; generated a test gradient instead.\n";
    }

    // Debug: Either print first few values or entire matrix if requested.
    // In TEST mode, suppress Core-level prints; main will print the final matrix.
    {
        const char* envFull = std::getenv("PRINT_FULL_MATRIX");
        const char* envTestLower = std::getenv("test");
        const char* envTestUpper = std::getenv("TEST");
        const bool isTest = (envTestLower && std::string(envTestLower) == "1") ||
                            (envTestUpper && std::string(envTestUpper) == "1");
        const bool print_full = (envFull && *envFull);
        if (!isTest) {
            if (!print_full) {
                std::size_t maxToPrint = std::min<std::size_t>(matrix.size(), 10);
                std::cout << "Debug: first " << maxToPrint << " values of matrix: ";
                for (std::size_t i = 0; i < maxToPrint; ++i) {
                    std::cout << static_cast<int>(matrix[i]) << ' ';
                }
                std::cout << "\n";
            } else {
                std::cout << "Debug: printing full matrix (" << origHeight << "x" << origWidth
                          << "x" << CHANNELS << ") as rows of (r,g,b) values\n";
                for (std::size_t y = 0; y < origHeight; ++y) {
                    for (std::size_t x = 0; x < origWidth; ++x) {
                        std::size_t idx = (y * origWidth + x) * CHANNELS;
                        int r = static_cast<int>(matrix[idx + 0]);
                        int g = static_cast<int>(matrix[idx + 1]);
                        int b = static_cast<int>(matrix[idx + 2]);
                        std::cout << '(' << r << ',' << g << ',' << b << ')';
                        if (x + 1 < origWidth) std::cout << ' ';
                    }
                    std::cout << '\n';
                }
            }
            std::cout << "Core::imageProcessor(): matrix ready ("
                      << CHANNELS << " × " << origHeight << " × " << origWidth << ")\n";
        }
    }
}

// mapToNearestColor: replace each pixel with nearest color from palette (Euclidean in RGB)
void Core::mapToNearestColor(const std::vector<std::array<uint8_t,3>>& palette) {
    if (palette.empty() || m == 0 || n == 0) return;
    const std::size_t width = m;
    const std::size_t height = n;
    const std::size_t CHANNELS = 3;

    auto dist2 = [](int r1, int g1, int b1, int r2, int g2, int b2) -> int {
        int dr = r1 - r2; int dg = g1 - g2; int db = b1 - b2;
        return dr*dr + dg*dg + db*db;
    };

    for (std::size_t y = 0; y < height; ++y) {
        for (std::size_t x = 0; x < width; ++x) {
            std::size_t idx = (y * width + x) * CHANNELS;
            int r = static_cast<int>(matrix[idx + 0]);
            int g = static_cast<int>(matrix[idx + 1]);
            int b = static_cast<int>(matrix[idx + 2]);

            int best = 0; int bestD = dist2(r, g, b, palette[0][0], palette[0][1], palette[0][2]);
            for (std::size_t pi = 1; pi < palette.size(); ++pi) {
                int d = dist2(r, g, b, palette[pi][0], palette[pi][1], palette[pi][2]);
                if (d < bestD) { bestD = d; best = static_cast<int>(pi); }
            }

            matrix[idx + 0] = palette[best][0];
            matrix[idx + 1] = palette[best][1];
            matrix[idx + 2] = palette[best][2];
        }
    }
}

// reduceBlocks: average non-overlapping blocks of size (blockM x blockN).
// If the image size is not a multiple of the block size, the trailing
// partial blocks are averaged as-is. Returns a new Core with reduced dims.
Core Core::reduceBlocks(std::size_t blockM, std::size_t blockN) const {
    const std::size_t CHANNELS = 3;
    if (m == 0 || n == 0) return Core(0, 0);
    if (blockM == 0) blockM = 1;
    if (blockN == 0) blockN = 1;

    const std::size_t newH = (n + blockM - 1) / blockM; // ceil(n/blockM)
    const std::size_t newW = (m + blockN - 1) / blockN; // ceil(m/blockN)

    Core out(newW, newH);
    out.matrix.assign(newH * newW * CHANNELS, 0);

    for (std::size_t oy = 0; oy < newH; ++oy) {
        std::size_t y0 = oy * blockM;
        std::size_t y1 = std::min(y0 + blockM, n);
        for (std::size_t ox = 0; ox < newW; ++ox) {
            std::size_t x0 = ox * blockN;
            std::size_t x1 = std::min(x0 + blockN, m);

            unsigned long long sumR = 0, sumG = 0, sumB = 0;
            std::size_t count = 0;
            for (std::size_t y = y0; y < y1; ++y) {
                for (std::size_t x = x0; x < x1; ++x) {
                    std::size_t idx = (y * m + x) * CHANNELS;
                    sumR += matrix[idx + 0];
                    sumG += matrix[idx + 1];
                    sumB += matrix[idx + 2];
                    ++count;
                }
            }
            if (count == 0) count = 1; // safety
            uint8_t r = static_cast<uint8_t>((sumR + count / 2) / count);
            uint8_t g = static_cast<uint8_t>((sumG + count / 2) / count);
            uint8_t b = static_cast<uint8_t>((sumB + count / 2) / count);

            std::size_t oidx = (oy * newW + ox) * CHANNELS;
            out.matrix[oidx + 0] = r;
            out.matrix[oidx + 1] = g;
            out.matrix[oidx + 2] = b;
        }
    }

    return out;
}

// matrixToBalls implementation stub
void Core::matrixToBalls() {
    // TODO: implement matrix-to-balls logic
}


void displayWallSimulation(/*balls*/){

  (void)std::system("python3 python/simulate_matrix_display.py > /dev/null 2>&1");
//
// python3 python/simulation/simulate_matrix_display.py

}



