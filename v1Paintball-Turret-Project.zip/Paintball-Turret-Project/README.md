# Paintball-Turret-Project
HI we are makeing the struct in CPP ill be updating the readme as i make code
