"""
Compatibility shim for older code that imported this module.

We now delegate to the canonical loader in `python/simulation/io.py`, which
resolves paths relative to the repo and supports optional overrides.
"""

from __future__ import annotations

from .io import load_rgb_matrix_from_bin  # re-export

__all__ = ["load_rgb_matrix_from_bin"]
