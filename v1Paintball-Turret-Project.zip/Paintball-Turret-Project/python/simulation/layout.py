from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional, Tuple


@dataclass(frozen=True)
class Layout:
    window_size: Tuple[int, int]
    scale: float
    step: float
    padding: float
    radius: float


def compute_image_layout(
    *,
    matrix_width: int,
    matrix_height: int,
    max_window_size: Optional[Tuple[int, int]] = None,
) -> Layout:
    if matrix_width <= 0 or matrix_height <= 0:
        raise ValueError("matrix must be non-empty")

    native_w = float(matrix_width)
    native_h = float(matrix_height)

    if max_window_size is None:
        return Layout(
            window_size=(int(math.ceil(native_w)), int(math.ceil(native_h))),
            scale=1.0,
            step=1.0,
            padding=0.0,
            radius=0.0,
        )

    max_w, max_h = max_window_size
    if max_w <= 0 or max_h <= 0:
        raise ValueError("max_window_size must be positive")

    scale = min(max_w / native_w, max_h / native_h)
    window_w = max(1, min(max_w, int(math.floor(native_w * scale))))
    window_h = max(1, min(max_h, int(math.floor(native_h * scale))))

    return Layout(window_size=(window_w, window_h), scale=scale, step=1.0, padding=0.0, radius=0.0)


def compute_layout(
    *,
    matrix_width: int,
    matrix_height: int,
    radius: float,
    max_window_size: Optional[Tuple[int, int]] = None,
) -> Layout:
    if matrix_width <= 0 or matrix_height <= 0:
        raise ValueError("matrix must be non-empty")
    if radius <= 0:
        raise ValueError("radius must be > 0")

    step = 2.0 * float(radius)
    padding = float(radius)

    native_w = (matrix_width - 1) * step + 2.0 * padding
    native_h = (matrix_height - 1) * step + 2.0 * padding

    if max_window_size is None:
        window_w = int(math.ceil(native_w))
        window_h = int(math.ceil(native_h))
        return Layout(window_size=(window_w, window_h), scale=1.0, step=step, padding=padding, radius=float(radius))

    max_w, max_h = max_window_size
    if max_w <= 0 or max_h <= 0:
        raise ValueError("max_window_size must be positive")

    scale = min(max_w / native_w, max_h / native_h)
    window_w = max(1, min(max_w, int(math.floor(native_w * scale))))
    window_h = max(1, min(max_h, int(math.floor(native_h * scale))))

    return Layout(window_size=(window_w, window_h), scale=scale, step=step, padding=padding, radius=float(radius))
