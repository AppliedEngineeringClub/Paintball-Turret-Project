from __future__ import annotations

import os
import sys
import math
from typing import Literal, Sequence, Tuple

import numpy as np
import pygame

if __package__ is None or __package__ == "":
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from simulation.layout import compute_image_layout, compute_layout
    from simulation.renderer import render_matrix
    from simulation.io import load_rgb_matrix_from_bin
else:
    from .layout import compute_image_layout, compute_layout
    from .renderer import render_matrix
    from .io import load_rgb_matrix_from_bin

DisplayMode = Literal["auto", "pixel", "blot"]





# <--------ONLY WORRY ABOUT THIS FUNCTION--------->

# displays a matrix
def simulate_matrix_display(
        matrix: Sequence[Sequence[Sequence[int]]],
        radius: float, mode: DisplayMode = "blot"
) -> None:
    """
    USAGE:
    param [Matrix] - Matrix of rgb values in the format of:
    [
        [[r,g,b], ...],
        ...
    ]

    param [radius] - The radius of a theoretical paintball splatter. Matrix values will
    offset so that "paint" doesn't overlap

    param [DisplayMode] - The type of display to use.
    1. Blot - Paint the image using circles to simulate a paintball shot. Its unrealistic
    to simulate a 1024x1024 image because it would require 1,048,576 individual blots

    2. Pixel - Displays the actual individual pixels. This just shows the image.
    3. Auto - Selects automatically


    """

    matrix_width, matrix_height = _matrix_dims(matrix)
    pygame.init()
    try:
        max_window = _max_window_size()
        chosen_mode = _choose_mode(mode, matrix_width, matrix_height)

        if chosen_mode == "pixel":
            layout, frame = _prepare_pixel_frame(matrix, matrix_width, matrix_height, max_window)
        else:
            layout, frame = _prepare_blot_frame(matrix, matrix_width, matrix_height, radius, max_window)

        screen = pygame.display.set_mode(layout.window_size)
        pygame.display.set_caption("Simulation")
        _run_event_loop(screen, frame)
    finally:
        pygame.quit()


# <------------------------HELPERS----------------------------->
def _max_window_size() -> Tuple[int, int]:
    info = pygame.display.Info()
    return max(200, info.current_w - 100), max(200, info.current_h - 100)


def _choose_mode(mode: DisplayMode, matrix_width: int, matrix_height: int) -> DisplayMode:
    if mode not in ("auto", "pixel", "blot"):
        raise ValueError('mode must be one of: "auto", "pixel", "blot"')
    if mode != "auto":
        return mode
    return "pixel" if (matrix_width * matrix_height) >= 200_000 else "blot"


def _prepare_pixel_frame(
        matrix: Sequence[Sequence[Sequence[int]]],
        matrix_width: int,
        matrix_height: int,
        max_window: Tuple[int, int],
):
    layout = compute_image_layout(
        matrix_width=matrix_width,
        matrix_height=matrix_height,
        max_window_size=max_window,
    )
    frame = render_matrix(matrix=matrix, layout=layout, mode="pixel")
    return layout, frame


def _prepare_blot_frame(
        matrix: Sequence[Sequence[Sequence[int]]],
        matrix_width: int,
        matrix_height: int,
        radius: float,
        max_window: Tuple[int, int],
):
    radius_px = _normalize_radius_px(radius, max_window)
    stride = _compute_blot_stride(matrix_width, matrix_height, radius_px, max_window)

    data = _as_uint8_matrix(matrix, matrix_width, matrix_height)
    if stride > 1:
        data = data[::stride, ::stride, :]

    blot_h, blot_w = int(data.shape[0]), int(data.shape[1])
    layout = compute_layout(
        matrix_width=blot_w,
        matrix_height=blot_h,
        radius=radius_px,
        max_window_size=None,
    )
    frame = render_matrix(matrix=data, layout=layout, mode="blot")
    return layout, frame


def _normalize_radius_px(radius: float, max_window: Tuple[int, int]) -> float:
    radius_px = float(radius)
    if radius_px <= 0:
        raise ValueError("radius must be > 0")
    if radius_px < 1.0:
        radius_px = max(1.0, radius_px * float(min(max_window)))
    return radius_px


def _compute_blot_stride(
        matrix_width: int,
        matrix_height: int,
        radius_px: float,
        max_window: Tuple[int, int],
) -> int:
    max_w, max_h = max_window
    max_cols = max(1, int(max_w // (2.0 * radius_px)))
    max_rows = max(1, int(max_h // (2.0 * radius_px)))

    stride_w = max(1, int(math.ceil(matrix_width / max_cols)))
    stride_h = max(1, int(math.ceil(matrix_height / max_rows)))

    max_blot_points = 50_000
    stride_points = max(1, int(math.ceil(math.sqrt((matrix_width * matrix_height) / max_blot_points))))
    return max(stride_w, stride_h, stride_points)


def _as_uint8_matrix(
        matrix: Sequence[Sequence[Sequence[int]]],
        matrix_width: int,
        matrix_height: int,
) -> np.ndarray:
    data = np.asarray(matrix, dtype=np.uint8)
    if data.shape != (matrix_height, matrix_width, 3):
        raise ValueError("matrix must have shape [height][width][3]")
    return data


def _run_event_loop(screen: pygame.Surface, frame: pygame.Surface) -> None:
    clock = pygame.time.Clock()
    keep_alive = True
    while keep_alive:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                keep_alive = False
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                keep_alive = False

        screen.blit(frame, (0, 0))
        pygame.display.flip()
        clock.tick(60)


def _matrix_dims(matrix: Sequence[Sequence[object]]) -> Tuple[int, int]:
    if not matrix:
        raise ValueError("matrix must be non-empty")
    height = len(matrix)
    width = len(matrix[0])
    if width == 0:
        raise ValueError("matrix must be non-empty")
    for row in matrix:
        if len(row) != width:
            raise ValueError("matrix must be rectangular")
    return width, height


if __name__ == "__main__":
    matrix = load_rgb_matrix_from_bin()
    simulate_matrix_display(matrix, radius=0.1, mode="blot")
