from __future__ import annotations

import math
from typing import Literal, Sequence, Tuple

import numpy as np
import pygame

from .layout import Layout


def _to_rgb(color: Sequence[int]) -> Tuple[int, int, int]:
    if len(color) != 3:
        raise ValueError("Each pixel must have 3 channels (RGB)")
    r, g, b = color
    return int(r) & 0xFF, int(g) & 0xFF, int(b) & 0xFF


def render_matrix(
    *,
    matrix: Sequence[Sequence[Sequence[int]]],
    layout: Layout,
    mode: Literal["auto", "pixel", "blot"] = "auto",
    background_rgb: Tuple[int, int, int] = (0, 0, 0),
) -> pygame.Surface:
    width, height = layout.window_size
    src_h = len(matrix)
    src_w = len(matrix[0]) if src_h else 0

    scaled_step_f = layout.step * layout.scale
    scaled_radius_f = layout.radius * layout.scale

    if mode not in ("auto", "pixel", "blot"):
        raise ValueError('mode must be one of: "auto", "pixel", "blot"')

    if mode == "auto":
        mode = "pixel" if (src_w * src_h) >= 200_000 or scaled_step_f < 2.0 or scaled_radius_f < 1.0 else "blot"

    if mode == "pixel":
        data = np.asarray(matrix, dtype=np.uint8)
        if data.shape != (src_h, src_w, 3):
            raise ValueError("matrix must have shape [height][width][3]")

        img = pygame.surfarray.make_surface(np.transpose(data, (1, 0, 2)))
        img = pygame.transform.smoothscale(img, (width, height))
        return img

    surface = pygame.Surface((width, height))
    surface.fill(background_rgb)

    scaled_padding_f = layout.padding * layout.scale
    scaled_radius = max(1, int(math.floor(scaled_radius_f)))

    for y, row in enumerate(matrix):
        cy = int(round(scaled_padding_f + y * scaled_step_f))
        for x, px in enumerate(row):
            cx = int(round(scaled_padding_f + x * scaled_step_f))
            pygame.draw.circle(surface, _to_rgb(px), (cx, cy), scaled_radius)

    return surface
