from __future__ import annotations

import json
from pathlib import Path
from typing import List, Optional


def load_rgb_matrix_from_bin(
    *,
    bin_path: Optional[str] = None,
    meta_path: Optional[str] = None,
) -> List[List[List[int]]]:
    repo_root = Path(__file__).resolve().parents[2]
    bin_file = Path(bin_path) if bin_path is not None else (repo_root / "image/out/pythonoutput.bin")
    meta_file = Path(meta_path) if meta_path is not None else (repo_root / "image/out/meta.json")

    if meta_path is None and not meta_file.exists():
        meta_file_alt = repo_root / "image/out " / "meta.json"
        if meta_file_alt.exists():
            meta_file = meta_file_alt

    if bin_path is None and not bin_file.exists():
        bin_file_alt = repo_root / "image/out " / "pythonoutput.bin"
        if bin_file_alt.exists():
            bin_file = bin_file_alt

    if not meta_file.exists():
        raise FileNotFoundError(
            f"Missing meta.json at {meta_file}. "
            f"Generate it by running: python3 python/get_matrix_data.py "
            f"(expects image/image.png), or pass meta_path=..."
        )
    if not bin_file.exists():
        raise FileNotFoundError(
            f"Missing pythonoutput.bin at {bin_file}. "
            f"Generate it by running: python3 python/get_matrix_data.py "
            f"(expects image/image.png), or pass bin_path=..."
        )

    meta = json.loads(meta_file.read_text(encoding="utf-8"))
    width = int(meta["width"])
    height = int(meta["height"])
    channels = int(meta.get("channels", 3))
    if channels != 3:
        raise ValueError(f"Expected 3 channels (RGB), got {channels}")

    raw = bin_file.read_bytes()
    expected_len = width * height * channels
    if len(raw) < expected_len:
        raise ValueError(f"Binary too small: got {len(raw)} bytes, expected {expected_len}")
    if len(raw) > expected_len:
        raw = raw[:expected_len]

    matrix: List[List[List[int]]] = []
    i = 0
    for _y in range(height):
        row: List[List[int]] = []
        for _x in range(width):
            row.append([raw[i], raw[i + 1], raw[i + 2]])
            i += 3
        matrix.append(row)
    return matrix
