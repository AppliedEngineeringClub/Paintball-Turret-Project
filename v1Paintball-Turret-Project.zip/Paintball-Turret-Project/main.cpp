#include <iostream>
#include <vector>
#include <array>
#include <cstdint>
#include <fstream>
#include <cstdlib> // for std::system
#include "core.hpp"

static bool parseByte(const char* s, uint8_t& out) {
    // parse integer and clamp to [0,255]
    try {
        int v = std::stoi(s);
        if (v < 0) v = 0;
        if (v > 255) v = 255;
        out = static_cast<uint8_t>(v);
        return true;
    } catch (...) {
        return false;
    }
}

int main(int argc, char** argv) {
    const char* testEnvLower = std::getenv("test");
    const char* testEnvUpper = std::getenv("TEST");
    bool isTest = (testEnvLower && std::string(testEnvLower) == "1") ||
                  (testEnvUpper && std::string(testEnvUpper) == "1");

    if (!isTest) {
        std::cout << "Starting Paintball Turret image test..." << std::endl;
    }

    // Expect 9 palette ints, optionally followed by: --block M N
    if (argc != 10 && argc != 13) {
        std::cerr << "Usage: " << argv[0]
                  << " R1 G1 B1 R2 G2 B2 R3 G3 B3 [--block M N]\n";
        std::cerr << "Example: " << argv[0]
                  << " 255 0 0  0 255 0  0 0 255 --block 4 4\n";
        return 2;
    }

    std::vector<std::array<uint8_t,3>> palette;
    palette.reserve(3);

    for (int i = 1; i < 10; i += 3) {
        uint8_t r, g, b;
        if (!parseByte(argv[i], r) || !parseByte(argv[i+1], g) || !parseByte(argv[i+2], b)) {
            std::cerr << "Invalid RGB value. Each must be an integer 0..255.\n";
            return 2;
        }
        palette.push_back({r, g, b});
    }

    // Optional block reduction args
    bool doReduce = false;
    std::size_t blockM = 0, blockN = 0;
    if (argc == 13) {
        std::string flag = argv[10];
        if (flag != "--block") {
            std::cerr << "Error: expected '--block M N' after palette values.\n";
            return 2;
        }
        try {
            int bm = std::stoi(argv[11]);
            int bn = std::stoi(argv[12]);
            if (bm <= 0 || bn <= 0) {
                std::cerr << "Error: block sizes must be positive integers.\n";
                return 2;
            }
            blockM = static_cast<std::size_t>(bm);
            blockN = static_cast<std::size_t>(bn);
            doReduce = true;
        } catch (...) {
            std::cerr << "Error: could not parse block sizes. Use '--block M N'.\n";
            return 2;
        }
    }

    try {
        Core core;
        core.imageProcessor();
        core.mapToNearestColor(palette);

        // If requested, reduce by averaging blocks
        if (doReduce) {
            Core reduced = core.reduceBlocks(blockM, blockN);
            core = std::move(reduced);
        }

        // Ensure output directory exists and overwrite the Python-produced binary
        (void)std::system("mkdir -p image/out > /dev/null 2>&1");
        const char* outPath = doReduce ? "image/out/reduced.bin" : "image/out/pythonoutput.bin";
        {
            std::ofstream out(outPath, std::ios::binary);
            if (out) {
                // Write exactly the number of bytes present in the matrix and
                // ensure they are flushed to disk before launching the simulator.
                out.write(reinterpret_cast<const char*>(core.matrix.data()),
                          static_cast<std::streamsize>(core.matrix.size()));
                out.flush();
                out.close();
                if (!isTest) {
                    if (doReduce) {
                        std::cout << "Wrote reduced image bytes to: " << outPath
                                  << " (" << core.n << "x" << core.m << "x3)\n";
                    } else {
                        std::cout << "Wrote quantized image bytes to: " << outPath
                                  << " (" << core.n << "x" << core.m << "x3)\n";
                    }
                }
            } else {
                std::cerr << "Warning: could not open output file to write image bytes.\n";
            }
        }

        // After producing the image bytes, launch the wall simulation (Python)
        // Uses pygame to render the result from image/out/pythonoutput.bin + meta.json
        // This mirrors the intended "wall" functionality without changing other files.
        {
            if (!isTest) {
                std::cout << "Launching wall simulation (pygame)..." << std::endl;
            }
            int rc = std::system("python3 python/simulation/simulate_matrix_display.py");
            if (rc != 0) {
                std::cerr << "Warning: wall simulation exited with code " << rc << "\n";
            }
        }

        // In TEST mode, print the final (post-mapping, post-reduction) matrix only.
        if (isTest) {
            const std::size_t width = core.m;
            const std::size_t height = core.n;
            const std::size_t CHANNELS = 3;
            for (std::size_t y = 0; y < height; ++y) {
                for (std::size_t x = 0; x < width; ++x) {
                    std::size_t idx = (y * width + x) * CHANNELS;
                    int r = static_cast<int>(core.matrix[idx + 0]);
                    int g = static_cast<int>(core.matrix[idx + 1]);
                    int b = static_cast<int>(core.matrix[idx + 2]);
                    std::cout << '(' << r << ',' << g << ',' << b << ')';
                    if (x + 1 < width) std::cout << ' ';
                }
                std::cout << '\n';
            }
        }
    } catch (const std::exception &e) {
        std::cerr << "Error: " << e.what() << std::endl;
        return 1;
    }

    if (!isTest) {
        std::cout << "Processing complete." << std::endl;
    }
    return 0;
}
